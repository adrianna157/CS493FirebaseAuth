
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'adriannaestelleguevarra',
  applicationName: 'music-api-app',
  appUid: 'qvdr8XQN2DSBqCMGbM',
  orgUid: '9a4bcc85-3da5-456d-8b1d-2c3e95ccfec2',
  deploymentUid: 'c55d2a65-3ccf-4135-a386-24ea17002373',
  serviceName: 'music-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'music-api-dev-addinglist', timeout: 6 };

try {
  const userHandler = require('./backend/AddAudio.js');
  module.exports.handler = serverlessSDK.handler(userHandler.addinglist, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}