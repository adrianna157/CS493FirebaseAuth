
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'adriannaestelleguevarra',
  applicationName: 'music-api-app',
  appUid: 'qvdr8XQN2DSBqCMGbM',
  orgUid: '9a4bcc85-3da5-456d-8b1d-2c3e95ccfec2',
  deploymentUid: '22b4ce7c-d7ff-4871-910d-2100c692a5df',
  serviceName: 'music-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'music-api-dev-getsonglist', timeout: 6 };

try {
  const userHandler = require('./backend/Songlist.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getsonglist, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}