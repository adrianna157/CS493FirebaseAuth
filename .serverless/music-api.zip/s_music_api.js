
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'adriannaestelleguevarra',
  applicationName: 'music-api-app',
  appUid: 'qvdr8XQN2DSBqCMGbM',
  orgUid: '9a4bcc85-3da5-456d-8b1d-2c3e95ccfec2',
  deploymentUid: '1b95527b-d0a3-4896-8536-3430a99c7816',
  serviceName: 'music-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'music-api-dev-music-api', timeout: 6 };

try {
  const userHandler = require('.//handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.musicapi, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}