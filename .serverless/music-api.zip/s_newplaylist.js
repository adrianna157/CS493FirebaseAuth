
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'adriannaestelleguevarra',
  applicationName: 'music-api-app',
  appUid: 'qvdr8XQN2DSBqCMGbM',
  orgUid: '9a4bcc85-3da5-456d-8b1d-2c3e95ccfec2',
  deploymentUid: '338a7e57-0ad8-4dcd-aa13-ceb2c1206ccc',
  serviceName: 'music-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'music-api-dev-newplaylist', timeout: 6 };

try {
  const userHandler = require('./backend/Customplay.js');
  module.exports.handler = serverlessSDK.handler(userHandler.newplaylist, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}