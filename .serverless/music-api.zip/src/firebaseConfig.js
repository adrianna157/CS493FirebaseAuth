import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyCYXHPho4i6pvnox1MBK9xdRpfxhhAo_cw",
  authDomain: "fir-auth-66e38.firebaseapp.com",
  projectId: "fir-auth-66e38",
  storageBucket: "fir-auth-66e38.appspot.com",
  messagingSenderId: "1026075082046",
  appId: "1:1026075082046:web:7d597e609e5d3ea212406f",
  measurementId: "G-NB10QG99YD",
};

firebase.initializeApp(firebaseConfig);

export default firebase;